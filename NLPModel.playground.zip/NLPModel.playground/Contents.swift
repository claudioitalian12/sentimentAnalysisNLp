import CreateML
import NaturalLanguage


let data = try MLDataTable(contentsOf: URL(fileURLWithPath: "csv or json path"))

let (trainingData, testingData) = data.randomSplit(by: 0.8, seed: 5)

let sentimentClassifier = try MLTextClassifier(trainingData: trainingData,
                                               textColumn: "text",
                                               labelColumn: "label")


// Training accuracy as a percentage
let trainingAccuracy = (1.0 - sentimentClassifier.trainingMetrics.classificationError) * 100



// Validation accuracy as a percentage
let validationAccuracy = (1.0 - sentimentClassifier.validationMetrics.classificationError) * 100



let evaluationMetrics = sentimentClassifier.evaluation(on: testingData)
let evaluationAccuracy = (1.0 - evaluationMetrics.classificationError) * 100



let metadata = MLModelMetadata(author: "name",
                               shortDescription: "A model trained to classify review sentiment",
                               version: "1.0")


try sentimentClassifier.write(to: URL(fileURLWithPath: "save path"),
                              metadata: metadata)



print("training accuracy:\(trainingAccuracy)")
print("validation Accuracy:\(validationAccuracy)")
print("evaluation Accuracy:\(validationAccuracy)")



//let sentimentPredictor = try NLModel(mlModel: sentimentClassifier.model)
//sentimentPredictor.predictedLabel(for: "boring")

